// Import Firebase modules (v11 modular)
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-app.js";
import { 
  getAuth, GoogleAuthProvider, signInWithPopup, 
  signInWithEmailAndPassword, createUserWithEmailAndPassword, 
  signOut, onAuthStateChanged, sendPasswordResetEmail 
} from "https://www.gstatic.com/firebasejs/11.3.1/firebase-auth.js";

// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCTOtlrui4Cgx_dfu3qp71pfo85PuV6uF4",
  authDomain: "shopping-assist-57165.firebaseapp.com",
  projectId: "shopping-assist-57165",
  storageBucket: "shopping-assist-57165.firebasestorage.app",
  messagingSenderId: "913825126711",
  appId: "1:913825126711:web:074315280f1ebdd21922b2",
  measurementId: "G-4CS6JBLZ1Q"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// Global variable to store product search results
let currentProducts = [];

// Get DOM elements
const loginModal = document.getElementById("loginModal");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");
const googleLoginBtn = document.getElementById("googleLogin");
const emailLoginBtn = document.getElementById("emailLogin");
const emailSignupBtn = document.getElementById("emailSignup");
const forgotPasswordBtn = document.getElementById("forgotPassword");
const closeModal = document.querySelector(".modal-content .close");

const chatMessages = document.getElementById("chatMessages");
const filterOptions = document.getElementById("filterOptions");

// --- Authentication Functions ---

// Show login modal
loginBtn.addEventListener('click', () => {
  loginModal.style.display = "block";
});

// Close modal when clicking the close icon or outside modal content
closeModal.addEventListener('click', () => {
  loginModal.style.display = "none";
});
window.addEventListener('click', (event) => {
  if (event.target === loginModal) {
    loginModal.style.display = "none";
  }
});

// Google Login
googleLoginBtn.addEventListener("click", () => {
  signInWithPopup(auth, googleProvider)
    .then((result) => {
      loginModal.style.display = "none";
      alert(`Welcome, ${result.user.displayName}!`);
      updateUI(true);
    })
    .catch((error) => {
      console.error("Google Sign-in error:", error);
      alert("Google Sign-in failed. Please ensure that Google Sign-In is enabled in your Firebase Console and that your domain (e.g., localhost) is authorized.");
    });
});

// Email/Password Login
emailLoginBtn.addEventListener("click", () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  
  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      loginModal.style.display = "none";
      alert("Login Successful!");
      updateUI(true);
    })
    .catch((error) => {
      alert("Login Failed: " + error.message);
    });
});

// Email/Password Sign Up
emailSignupBtn.addEventListener("click", () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  
  if (!email || !password) {
    alert("Please enter both email and password for sign up.");
    return;
  }

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      alert("Signup Successful! Please login.");
    })
    .catch((error) => {
      alert("Signup Failed: " + error.message);
    });
});

// Forgot Password
forgotPasswordBtn.addEventListener("click", () => {
  const email = document.getElementById("email").value.trim();
  if (!email) {
    alert("Please enter your email address to reset your password.");
    return;
  }
  sendPasswordResetEmail(auth, email)
    .then(() => {
      alert("Password reset email sent! Check your inbox.");
    })
    .catch((error) => {
      alert("Error sending password reset email: " + error.message);
    });
});

// Logout
logoutBtn.addEventListener('click', () => {
  signOut(auth)
    .then(() => {
      alert("Logged out successfully!");
      updateUI(false);
    })
    .catch((error) => {
      alert("Logout failed: " + error.message);
    });
});

// Listen for Authentication State Changes
onAuthStateChanged(auth, (user) => {
  updateUI(!!user);
});

// Update UI based on login state
function updateUI(isLoggedIn) {
  if (isLoggedIn) {
    loginBtn.style.display = "none";
    logoutBtn.style.display = "inline-block";
  } else {
    loginBtn.style.display = "inline-block";
    logoutBtn.style.display = "none";
  }
}

// --- Chat & Product Functions ---

// Append a chat message to the chat area with animation
function appendMessage(text, isUser = false) {
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
  messageDiv.innerHTML = `<div class="message-content">${text}</div>`;
  chatMessages.appendChild(messageDiv);
  messageDiv.style.animation = 'fadeInMessage 0.5s forwards';
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Render product cards based on a given product array
function renderProducts(products) {
  // Remove existing product cards
  document.querySelectorAll('.product-card').forEach(card => card.remove());
  
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    
    let buyNowHTML = "";
    if (product.link && product.link !== "#" && product.link !== "") {
      buyNowHTML = `<a href="${product.link}" class="buy-link" target="_blank">Buy Now</a>`;
    } else {
      buyNowHTML = `<button class="buy-link" disabled>Not Available</button>`;
    }
    
    productCard.innerHTML = `
      <h3>${product.name}</h3>
      <p>Price: ₹${product.price}</p>
      <p>Rating: ${product.rating}/5 ⭐</p>
      <div class="button-group">
        ${buyNowHTML}
        <button class="add-cart" onclick='addToCart(${JSON.stringify(product)})'>Add to Cart</button>
      </div>
    `;
    chatMessages.appendChild(productCard);
    productCard.style.animation = 'slideIn 0.5s forwards';
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Show products and enable filter options
function showProducts(products) {
  currentProducts = products;
  appendMessage("Here are the best products I found:");
  renderProducts(products);
  filterOptions.style.display = "block";
}

// Filter functions (sort the currentProducts array)
function applyFilter(criteria) {
  if (!currentProducts.length) return;
  let sorted = [...currentProducts];
  switch(criteria) {
    case "highPrice":
      sorted.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
      break;
    case "moreRating":
      sorted.sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
      break;
    case "morePopular":
      sorted.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
      break;
    case "bestProduct":
      sorted.sort((a, b) => {
        if (parseFloat(b.rating) === parseFloat(a.rating)) return parseFloat(a.price) - parseFloat(b.price);
        return parseFloat(b.rating) - parseFloat(a.rating);
      });
      break;
    default:
      break;
  }
  renderProducts(sorted);
}

// Send product query to backend
async function sendQuery() {
  const query = document.getElementById('userInput').value.trim();
  if (!query) return;
  
  appendMessage(query, true);
  document.getElementById('userInput').value = '';

  try {
    const response = await fetch('/get-products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: query })
    });
    
    if (!response.ok) throw new Error('Network error');
    
    const data = await response.json();
    showProducts(data.products);
  } catch (error) {
    appendMessage("Oops! Something went wrong. Please try again.");
    console.error(error);
  }
}

// Trigger search on Enter key press
document.getElementById('userInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendQuery();
});

// Set trending keyword in search box when clicked
function setKeyword(keyword) {
  document.getElementById('userInput').value = keyword;
  document.getElementById('userInput').focus();
}

// Dummy Add-to-Cart function (requires user to be logged in)
async function addToCart(product) {
  if (!auth.currentUser) {
    alert("Please login to add items to your cart.");
    return;
  }
  alert(`Product "${product.name}" added to your cart!`);
}
