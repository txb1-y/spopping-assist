from flask import Flask, request, jsonify, render_template, redirect, url_for
import requests
from flask_mail import Mail, Message

app = Flask(__name__)

# ---------------------------
# Configuration for Product Search
# ---------------------------
AMAZON_TAG = "YOUR_AMAZON_TAG"       # Replace with your Amazon affiliate tag
FLIPKART_ID = "YOUR_FLIPKART_ID"     # Replace with your Flipkart affiliate ID
SERPAPI_KEY = "fafb0925f67b8c189b26c3d38badae4f51f42c0c800053694201aea2f5d2320c"
SERPAPI_URL = "https://serpapi.com/search"

def add_affiliate_links(url):
    if "amazon.in" in url:
        return f"{url}?tag={AMAZON_TAG}" if "?" not in url else f"{url}&tag={AMAZON_TAG}"
    elif "flipkart.com" in url:
        return f"{url}?affid={FLIPKART_ID}" if "?" not in url else f"{url}&affid={FLIPKART_ID}"
    return url

def get_products_from_query(query):
    params = {
        "engine": "google_shopping",
        "q": query,
        "api_key": SERPAPI_KEY,
        "gl": "in",    # For Indian rupees
        "hl": "en"
    }
    try:
        response = requests.get(SERPAPI_URL, params=params)
        response.raise_for_status()
        result = response.json()
        products = []
        # Parse results from the "shopping_results" key
        for item in result.get("shopping_results", []):
            products.append({
                "name": item.get("title", "No Title"),
                "price": item.get("price", "N/A"),
                "rating": item.get("rating", "No rating"),
                "popularity": item.get("reviews", 0),
                "link": add_affiliate_links(item.get("link", "#"))
            })
        if not products:
            products.append({
                "name": "No products found",
                "price": 0,
                "rating": 0,
                "popularity": 0,
                "link": "#"
            })
        return products
    except Exception as e:
        print("Error fetching products from SerpAPI:", e)
        return [{
            "name": "Error fetching products",
            "price": 0,
            "rating": 0,
            "popularity": 0,
            "link": "#"
        }]

# ---------------------------
# Email Feedback Configuration using Flask-Mail
# ---------------------------
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'your_email@gmail.com'      # Replace with your email
app.config['MAIL_PASSWORD'] = 'your_email_password'       # Replace with your email password or app password
app.config['MAIL_DEFAULT_SENDER'] = app.config['MAIL_USERNAME']

mail = Mail(app)

# ---------------------------
# Routes
# ---------------------------

@app.route('/')
def home():
    return render_template('index.html')  # Looks for templates/index.html

@app.route('/get-products', methods=['POST'])
def handle_query():
    query = request.json.get('query', '').strip()
    if not query:
        return jsonify({"error": "Empty query"}), 400
    products = get_products_from_query(query)
    return jsonify({"products": products})

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        name = request.form.get('name')
        sender_email = request.form.get('email')
        feedback_message = request.form.get('feedback')
        
        # Create email message
        msg = Message("Feedback from " + name,
                      recipients=["bharathibalu101@gmail.com"])  # Updated recipient email
        msg.body = f"Name: {name}\nEmail: {sender_email}\n\nFeedback:\n{feedback_message}"
        
        try:
            mail.send(msg)
            return redirect(url_for('feedback_thankyou'))
        except Exception as e:
            print("Error sending feedback email:", e)
            return "There was an error sending your feedback. Please try again."
    
    return render_template('feedback.html')  # Looks for templates/feedback.html

@app.route('/feedback-thankyou')
def feedback_thankyou():
    return "Thank you for your feedback!"

if __name__ == '__main__':
    app.run(debug=True, port=5000)
